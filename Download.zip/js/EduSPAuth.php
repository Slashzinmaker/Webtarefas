<?php

class EduSPAuth {
    private $subscriptionKey;
    private $baseUrl = "https://edusp-api.ip.tv/";
    private $loginUrl = "https://see-p-credenciais.azurewebsites.net/api/LoginCompletoToken";
    private $headers = [
        'Content-Type' => 'application/json',
        'Accept' => 'application/json',
        'Origin' => 'https://edusp.ip.tv',
        'Referer' => 'https://edusp.ip.tv/',
        'X-Api-Realm' => 'edusp',
        'X-Api-Platform' => 'webclient',
        'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ];

    public function __construct($subscriptionKey) {
        $this->subscriptionKey = $subscriptionKey;
    }

    public function login($ra, $password) {
        $payload = json_encode([
            'user' => $ra,
            'senha' => $password
        ]);

        $options = [
            'http' => [
                'header'  => "Content-Type: application/json\r\n" .
                             "Accept: application/json\r\n" .
                             "Ocp-Apim-Subscription-Key: " . $this->subscriptionKey . "\r\n",
                'method'  => 'POST',
                'content' => $payload,
                'ignore_errors' => true,
                'timeout' => 15
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false
            ]
        ];

        $context = stream_context_create($options);
        $response = file_get_contents($this->loginUrl, false, $context);

        if ($response === FALSE) {
            $error = error_get_last();
            throw new Exception("Falha na requisição de login: " . $error['message']);
        }

        $responseData = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Resposta inválida da API de login");
        }

        if (!isset($responseData['token'])) {
            throw new Exception("Token não retornado na resposta");
        }

        return [
            'token' => $responseData['token'],
            'nickname' => isset($responseData['DadosUsuario']['NM_NICK']) ? 
                $responseData['DadosUsuario']['NM_NICK'] . '-sp' : null,
            'cpf' => isset($responseData['DadosUsuario']['NR_CPF']) ? $responseData['DadosUsuario']['NR_CPF'] : null,
            'email' => isset($responseData['DadosUsuario']['DS_EMAIL']) ? $responseData['DadosUsuario']['DS_EMAIL'] : null,
            'ra' => $ra
        ];
    }

    public function registerToken($tokenData) {
        $payload = [
            'token' => $tokenData['token'],
            'realm' => 'edusp',
            'platform' => 'webclient',
            'nickname' => $tokenData['nickname'],
            'cpf' => $tokenData['cpf'],
            'email' => $tokenData['email'],
            'login_method' => 'SED',
            'ra' => $tokenData['ra']
        ];

        // Remove campos vazios
        $payload = array_filter($payload, function($value) {
            return $value !== null && $value !== '';
        });

        $url = $this->baseUrl . "registration/edusp/token";
        $payloadJson = json_encode($payload);

        $headers = $this->headers;
        $headers['Ocp-Apim-Subscription-Key'] = $this->subscriptionKey;
        $headers['Authorization'] = 'Bearer ' . $tokenData['token'];
        $headers['Content-Length'] = strlen($payloadJson);

        $headerString = '';
        foreach ($headers as $key => $value) {
            $headerString .= "$key: $value\r\n";
        }

        $options = [
            'http' => [
                'header'  => $headerString,
                'method'  => 'POST',
                'content' => $payloadJson,
                'ignore_errors' => true,
                'timeout' => 20
            ],
            'ssl' => [
                'verify_peer' => false,
                'verify_peer_name' => false
            ]
        ];

        $context = stream_context_create($options);
        $response = file_get_contents($url, false, $context);

        if ($response === FALSE) {
            $error = error_get_last();
            throw new Exception("Falha na requisição de registro: " . $error['message']);
        }

        $responseData = json_decode($response, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception("Resposta inválida da API de registro");
        }

        if (!isset($responseData['auth_token'])) {
            throw new Exception("Auth token não retornado na resposta");
        }

        return [
            'auth_token' => $responseData['auth_token'],
            'full_response' => $responseData
        ];
    }

    public function getStudentTasks($user, $expiredOnly = false) {
        // Busca as salas do usuário
        $roomsResponse = $this->makeApiRequest(
            $this->baseUrl . "room/user?list_all=true&with_cards=true", 
            'GET', 
            [], 
            array_merge($this->headers, [
                'Ocp-Apim-Subscription-Key: ' . $this->subscriptionKey,
                'Authorization: Bearer ' . $user['token'],
                'x-api-key: ' . $user['auth_token']
            ])
        );

        $rooms = $roomsResponse['success'] ? ($roomsResponse['data']['rooms'] ?? []) : [];
        $roomNames = array_column($rooms, 'name');

        // Monta a URL para buscar tarefas
        $url = $this->baseUrl . 'tms/task/todo?' . http_build_query([
            'expired_only' => $expiredOnly ? 'true' : 'false',
            'filter_expired' => $expiredOnly ? 'false' : 'true',
            'with_answer' => 'true',
            'answer_statuses' => 'pending',
            'with_apply_moment' => $expiredOnly ? 'true' : 'false'
        ]);

        if (!empty($roomNames)) {
            $url .= '&' . http_build_query(['publication_target' => $roomNames]);
        }

        // Busca as tarefas
        $tasksResponse = $this->makeApiRequest(
            $url, 
            'GET', 
            [], 
            array_merge($this->headers, [
                'Ocp-Apim-Subscription-Key: ' . $this->subscriptionKey,
                'Authorization: Bearer ' . $user['token'],
                'x-api-key: ' . $user['auth_token']
            ])
        );

        if (!$tasksResponse['success']) {
            throw new Exception('Falha ao buscar tarefas');
        }

        $tasks = $tasksResponse['data'] ?? [];

        // Filtra tarefas e remove redações
        $filteredTasks = array_filter($tasks, function($task) {
            if (!isset($task['id'])) return false;
            
            // Verifica se é uma redação pelo título
            if (isset($task['title']) && stripos($task['title'], 'redacao') !== false) {
                return false;
            }
            
            // Verifica pelas tags
            if (isset($task['tags'])) {
                foreach ($task['tags'] as $tag) {
                    if (stripos($tag, 'redacao') !== false) {
                        return false;
                    }
                }
            }
            
            return true;
        });

        // Formata as tarefas para o frontend
        $formattedTasks = array_map(function($task) {
            return [
                'id' => $task['id'],
                'title' => $task['title'] ?? 'Tarefa sem título',
                'description' => $task['description'] ?? null,
                'subject' => $task['subject'] ?? null,
                'deadline' => $task['deadline'] ?? null,
                'status' => isset($task['expired']) && $task['expired'] ? 'expired' : 'pending',
                'duration' => null
            ];
        }, $filteredTasks);

        return array_values($formattedTasks);
    }

    public function submitTask($user, $taskId, $minTime = 600, $maxTime = 1200) {
        // 1. Carrega os detalhes da tarefa
        $task = $this->makeApiRequest(
            $this->baseUrl . 'tms/task/' . $taskId . '/apply?preview_mode=false', 
            'GET', 
            [], 
            array_merge($this->headers, [
                'Ocp-Apim-Subscription-Key: ' . $this->subscriptionKey,
                'Authorization: Bearer ' . $user['token'],
                'x-api-key: ' . $user['auth_token']
            ])
        );

        if (!$task['success']) {
            throw new Exception('Não foi possível carregar os detalhes da tarefa');
        }

        $task = $task['data'];

        // 2. Prepara as respostas
        $answers = [];
        if (isset($task['questions'])) {
            foreach ($task['questions'] as $question) {
                if ($question['type'] === 'info') continue;
                
                $answer = [];
                
                if ($question['type'] === 'media') {
                    $answer = ['status' => 'error', 'message' => 'Type=media system require url'];
                } elseif (isset($question['options'])) {
                    // Para questões de múltipla escolha, seleciona uma opção aleatória
                    $options = array_values($question['options']);
                    $randomIndex = array_rand($options);
                    
                    foreach ($options as $i => $option) {
                        $answer[$i] = ($i === $randomIndex);
                    }
                }
                
                $answers[strval($question['id'])] = [
                    'question_id' => strval($question['id']),
                    'question_type' => $question['type'],
                    'answer' => $answer
                ];
            }
        }

        // 3. Submete a tarefa
        $duration = rand($minTime, $maxTime + 1); // Gera um tempo aleatório entre min e max
        
        $draft = [
            'status' => 'submitted',
            'accessed_on' => 'room',
            'executed_on' => $task['publication_target'] ?? null,
            'duration' => $duration,
            'answers' => $answers
        ];

        $submitResponse = $this->makeApiRequest(
            $this->baseUrl . 'tms/task/' . $taskId . '/answer',
            'POST',
            $draft,
            array_merge($this->headers, [
                'Ocp-Apim-Subscription-Key: ' . $this->subscriptionKey,
                'Authorization: Bearer ' . $user['token'],
                'x-api-key: ' . $user['auth_token']
            ])
        );

        if (!$submitResponse['success'] || !isset($submitResponse['data']['id'])) {
            throw new Exception('Falha ao submeter a tarefa');
        }

        $answerId = $submitResponse['data']['id'];

        // 4. Obtém as respostas corretas (opcional)
        $correctAnswers = $this->getCorrectAnswers($taskId, $answerId, $user);

        // 5. Atualiza com as respostas corretas (opcional)
        if ($correctAnswers) {
            $this->makeApiRequest(
                $this->baseUrl . 'tms/task/' . $taskId . '/answer/' . $answerId,
                'PUT',
                $correctAnswers,
                array_merge($this->headers, [
                    'Ocp-Apim-Subscription-Key: ' . $this->subscriptionKey,
                    'Authorization: Bearer ' . $user['token'],
                    'x-api-key: ' . $user['auth_token']
                ])
            );
        }

        return [
            'success' => true,
            'task_id' => $taskId,
            'answer_id' => $answerId
        ];
    }

    private function getCorrectAnswers($taskId, $answerId, $user) {
        $response = $this->makeApiRequest(
            $this->baseUrl . 'tms/task/' . $taskId . '/answer/' . $answerId . '?with_task=true&with_genre=true&with_questions=true&with_assessed_skills=true',
            'GET',
            [],
            array_merge($this->headers, [
                'Ocp-Apim-Subscription-Key: ' . $this->subscriptionKey,
                'Authorization: Bearer ' . $user['token'],
                'x-api-key: ' . $user['auth_token']
            ])
        );

        if (!$response['success']) {
            return false;
        }

        return $this->formatAnswers($response['data']);
    }

    private function formatAnswers($data) {
        if (!isset($data['task']['questions']) || !isset($data['answers'])) {
            return false;
        }

        $result = [
            'accessed_on' => $data['accessed_on'] ?? 'room',
            'executed_on' => $data['executed_on'] ?? null,
            'answers' => []
        ];

        foreach ($data['answers'] as $qId => $qData) {
            $question = null;
            foreach ($data['task']['questions'] as $q) {
                if (strval($q['id']) === strval($qId)) {
                    $question = $q;
                    break;
                }
            }

            if (!$question) continue;

            $answer = [
                'question_id' => strval($qData['question_id']),
                'question_type' => $question['type']
            ];

            switch ($question['type']) {
                case 'order-sentences':
                    $answer['answer'] = array_map(function($s) { return $s['value']; }, $question['options']['sentences']);
                    break;
                case 'fill-words':
                    $answer['answer'] = array_map(function($p) { return $p['value']; }, 
                        array_filter($question['options']['phrase'], function($_, $i) { return $i % 2; }, ARRAY_FILTER_USE_BOTH));
                    break;
                case 'text_ai':
                    $answer['answer'] = ['0' => preg_replace('/<[^>]*>/', '', $question['comment'] ?? '')];
                    break;
                case 'fill-letters':
                    $answer['answer'] = $question['options']['answer'];
                    break;
                case 'cloud':
                    $answer['answer'] = $question['options']['ids'];
                    break;
                default:
                    $formatted = [];
                    foreach ($question['options'] as $id => $opt) {
                        $formatted[$id] = $opt['answer'] ?? false;
                    }
                    $answer['answer'] = $formatted;
            }

            $result['answers'][strval($qId)] = $answer;
        }

        return $result;
    }

    private function makeApiRequest($url, $method = 'GET', $data = [], $headers = []) {
        $ch = curl_init($url);

        $options = [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HEADER => false,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_CUSTOMREQUEST => strtoupper($method),
            CURLOPT_HTTPHEADER => $headers
        ];

        if ($method === 'POST' || $method === 'PUT') {
            $jsonData = json_encode($data);
            $options[CURLOPT_POSTFIELDS] = $jsonData;
            $headers[] = 'Content-Length: ' . strlen($jsonData);
        }

        curl_setopt_array($ch, $options);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($error) {
            return ['success' => false, 'message' => $error];
        }

        $decoded = json_decode($response, true) ?? $response;

        if ($httpCode >= 200 && $httpCode < 300) {
            return ['success' => true, 'data' => $decoded];
        } else {
            return [
                'success' => false,
                'message' => $decoded['message'] ?? 'Erro na requisição',
                'code' => $httpCode,
                'data' => $decoded
            ];
        }
    }
}
?>